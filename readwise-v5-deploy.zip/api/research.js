// Deep research: gathers real sources (Wikipedia, OpenAlex scholarly works, Google Books) then asks AI to synthesise with citations.
const { limited, body, chat, sameOrigin } = require("../lib/ai.js");
const UA = { "User-Agent": "READWISE/2.0 (student study app)" };
const get = async (u) => { const c = new AbortController(), t = setTimeout(() => c.abort(), 9000); try { const r = await fetch(u, { headers: UA, signal: c.signal }); return r.ok ? await r.json() : {}; } catch { return {}; } finally { clearTimeout(t); } };
const clip = (s, n) => String(s || "").replace(/\s+/g, " ").trim().slice(0, n);
async function wiki(q) {
  const d = await get("https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=" + encodeURIComponent(q) + "&gsrlimit=3&prop=extracts|info&exintro=1&explaintext=1&exchars=800&inprop=url&format=json&origin=*");
  return Object.values((d.query && d.query.pages) || {}).map(p => ({ type: "Encyclopedia", title: p.title, url: p.fullurl, text: clip(p.extract, 800) }));
}
function abs(ix) { if (!ix) return ""; const w = []; for (const k in ix) ix[k].forEach(i => { w[i] = k; }); return w.join(" "); }
async function scholar(q) {
  const d = await get("https://api.openalex.org/works?search=" + encodeURIComponent(q) + "&per-page=6&select=title,publication_year,doi,id,abstract_inverted_index,cited_by_count");
  return (d.results || []).filter(w => w.title).map(w => ({ type: "Scholarly paper" + (w.publication_year ? " (" + w.publication_year + ")" : ""), title: w.title, url: w.doi || w.id, text: clip(abs(w.abstract_inverted_index), 700) }));
}
async function books(q) {
  const d = await get("https://www.googleapis.com/books/v1/volumes?printType=books&maxResults=4&q=" + encodeURIComponent(q));
  return (d.items || []).map(i => ({ type: "Book", title: (i.volumeInfo.title || "") + (i.volumeInfo.authors ? " - " + i.volumeInfo.authors.join(", ") : ""), url: i.volumeInfo.infoLink, text: clip(i.volumeInfo.description, 500) }));
}
module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST." });
  if (!sameOrigin(req)) return res.status(403).json({ error: "Forbidden." });
  if (limited(req, 5)) return res.status(429).json({ error: "Too many research requests. Wait a minute." });
  const topic = String(body(req).topic || "").trim().slice(0, 200);
  if (!topic) return res.status(400).json({ error: "Enter a topic." });
  const [w, s, bk] = await Promise.all([wiki(topic), scholar(topic), books(topic)].map(p => p.catch(() => [])));
  const sources = [...w, ...s, ...bk].filter(x => x.title).map((x, i) => ({ n: i + 1, ...x }));
  const ctx = sources.map(x => "[" + x.n + "] " + x.type + ": " + x.title + "\n" + x.text).join("\n\n");
  const report = await chat([
    { role: "system", content: "You are a university research assistant. Write a structured research brief on the topic. Use ONLY the numbered sources for factual claims and cite them like [1] or [2][3]. If sources are thin, say so and clearly label anything from general knowledge. Sections: Overview, Key concepts, Current understanding and debates, How to study this further, 5 study questions. Plain, clear language. Never invent sources." },
    { role: "user", content: "Topic: " + topic + "\n\nSources:\n" + (ctx || "(none found)") }], 2200);
  res.status(200).json({ report, sources: sources.map(({ n, type, title, url }) => ({ n, type, title, url })) });
};
