// Safe diagnostics: reports whether the API runs and which AI mode is active. Never returns secrets.
module.exports = (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.status(200).json({ ok: true, version: "5.0.0", ai: process.env.AI_API_KEY ? "provider-configured" : process.env.AI_FREE_FALLBACK === "off" ? "off" : "free-fallback" });
};
