"use strict";
/* Local-first data layer: versioning, migration, validation, backups, CSV. Pure helpers are unit-tested. */
const DATA_VERSION=4;
function safeParse(t){if(typeof t!=="string"||t.length>2e6)throw Error("File is too large to be a READWISE backup.");try{return JSON.parse(t,(k,v)=>k==="__proto__"?undefined:v)}catch{throw Error("That file is not valid JSON.")}}
function migrateData(s,base){s=s&&typeof s==="object"&&!Array.isArray(s)?s:{};const d=Object.assign({},base,s);["profile","cgpa","settings"].forEach(k=>{d[k]=Object.assign({},base[k],s[k]||{})});if(!d.cgpa.resit)d.cgpa.resit="all";if(!d.exams||!Array.isArray(d.exams.list))d.exams={list:[]};if((s.v||3)<4)d.migratedFrom=s.v||3;d.v=DATA_VERSION;return d}
function validateImport(o){const bad=m=>{throw Error("Invalid backup: "+m)};
if(!o||typeof o!=="object"||Array.isArray(o))bad("this is not a READWISE data file.");
if(!o.profile||typeof o.profile!=="object"||!o.cgpa||!Array.isArray(o.cgpa.semesters))bad("profile or results are missing.");
if(o.v>DATA_VERSION)bad("it was made by a newer version of READWISE.");
for(const s of o.cgpa.semesters){if(!s||!Array.isArray(s.courses))bad("a semester is malformed.");for(const c of s.courses)if(!c||typeof c.code!=="string"||!(c.units>=0&&c.units<=12)||!/^[A-F]$/.test(c.grade))bad("course "+(c&&String(c.code).slice(0,20))+" is malformed.")}
for(const k of["tasks","activity"])if(o[k]!==undefined&&(!o[k]||typeof o[k]!=="object"||Array.isArray(o[k])))bad(k+" is malformed.");
for(const k of["shelf","audio","quizzes","roadmap","daily","chat","custom","savedOps"])if(o[k]!==undefined&&!Array.isArray(o[k]))bad(k+" is malformed.");
if(o.exams!==undefined&&!(o.exams&&Array.isArray(o.exams.list)))bad("exams are malformed.");return true}
const csvCell=v=>{let s=String(v??"");if(/^[=+\-@\t\r]/.test(s))s="'"+s;return/[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s};
function resultsCSV(g){const r=[["Semester","Course","Title","Units","Score","Grade","Resit"]];g.semesters.forEach(s=>s.courses.forEach(c=>r.push([s.name,c.code,c.title||"",c.units,c.score,c.grade,c.retake?"yes":"no"])));return r.map(x=>x.map(csvCell).join(",")).join("\r\n")}
function makeBackup(email,day){try{const raw=localStorage.getItem("rw_data_"+email),b=JSON.parse(localStorage.getItem("rw_backup_"+email)||"null");if(raw&&(!b||b.date!==day))localStorage.setItem("rw_backup_"+email,JSON.stringify({date:day,raw}))}catch{}}
function readBackup(email){try{return JSON.parse(localStorage.getItem("rw_backup_"+email)||"null")}catch{return null}}
