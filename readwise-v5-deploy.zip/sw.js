const CACHE="readwise-v10";
const FILES=["/","/index.html","/404.html","/manifest.webmanifest","/icon.svg","/style.css","/boot.js","/core.js","/home.js","/focus.js","/datalayer.js","/offline.html","/icon-192.png","/icon-512.png","/tasks.js","/cgpa.js","/studio.js","/library.js","/cbt.js","/opportunities.js","/misc.js"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)));self.skipWaiting();});
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
self.addEventListener("fetch",e=>{
  const u=new URL(e.request.url);
  if(e.request.method!=="GET"||u.origin!==location.origin||u.pathname.startsWith("/api/"))return;
  e.respondWith(fetch(e.request).then(r=>{if(r.ok){const c=r.clone();caches.open(CACHE).then(x=>x.put(e.request,c));}return r;}).catch(()=>caches.match(e.request).then(m=>m||(e.request.mode==="navigate"?caches.match("/"):undefined)).then(m=>m||(e.request.mode==="navigate"?caches.match("/offline.html"):undefined))));
});
self.addEventListener("notificationclick",e=>{e.notification.close();e.waitUntil(self.clients.matchAll({type:"window"}).then(cs=>cs.length?cs[0].focus():self.clients.openWindow("/")));});
