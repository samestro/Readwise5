// Local Vercel simulator: applies vercel.json headers + cleanUrls redirects and runs /api/* handlers.
const http=require("http"),fs=require("fs"),path=require("path"),root=path.join(__dirname,"..");
const cfg=JSON.parse(fs.readFileSync(path.join(root,"vercel.json"),"utf8"));
const mime={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css",".svg":"image/svg+xml",".png":"image/png",".webmanifest":"application/manifest+json"};
const hdrs=u=>{const h={};for(const r of cfg.headers||[]){if(new RegExp("^"+r.source.replace(/\(\.\*\)/g,".*")+"$").test(u))r.headers.forEach(x=>h[x.key]=x.value)}return h};
http.createServer(async(req,res)=>{
 let u=decodeURIComponent(req.url.split("?")[0]);const H=hdrs(u);
 const send=(c,b,t,extra)=>{res.writeHead(c,{...H,"Content-Type":t||"text/plain",...(extra||{})});res.end(b)};
 if(u.startsWith("/api/")){const f=path.join(root,u+".js");if(!fs.existsSync(f))return send(404,"Not found");
  let raw="";for await(const c of req)raw+=c;let b=raw;try{b=JSON.parse(raw)}catch{}
  const r={method:req.method,headers:req.headers,body:b},o={setHeader:(k,v)=>res.setHeader(k,v),status(c){res.statusCode=c;return o},json(j){res.setHeader("Content-Type","application/json");res.end(JSON.stringify(j))}};
  try{await require(f)(r,o)}catch(e){send(500,JSON.stringify({error:"Server error"}),"application/json")}return}
 if(cfg.cleanUrls&&/\.html$/.test(u))return send(308,"",null,{Location:u.replace(/\/index\.html$/,"/").replace(/\.html$/,"")||"/"});
 let f=path.join(root,u==="/"?"index.html":u);if(!fs.existsSync(f)&&fs.existsSync(f+".html"))f+=".html";
 if(!fs.existsSync(f)||fs.statSync(f).isDirectory())return send(404,fs.readFileSync(path.join(root,"404.html")),"text/html; charset=utf-8");
 send(200,fs.readFileSync(f),mime[path.extname(f)]||"application/octet-stream")}).listen(+process.argv[2]||8765);
