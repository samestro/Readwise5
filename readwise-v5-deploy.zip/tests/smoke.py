# Real-browser smoke test: python3 tests/smoke.py  (needs playwright + chromium)
import subprocess,time,sys,json
from playwright.sync_api import sync_playwright
srv=subprocess.Popen(["node","tests/server.js","8765"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1)
errs=[];res=[]
def go(t):pg.evaluate("t=>tab(t)",t)
def ok(n,c):res.append((n,bool(c)));print(("PASS " if c else "FAIL ")+n)
try:
  with sync_playwright() as p:
    b=p.chromium.launch();ctx=b.new_context(viewport={"width":360,"height":780},accept_downloads=True);pg=ctx.new_page()
    pg.on("console",lambda m:errs.append(m.text) if m.type=="error" else None);pg.on("pageerror",lambda e:errs.append(str(e)))
    c2=b.new_context();p2=c2.new_page();p2.route("**/tasks.js",lambda r:r.abort());p2.goto("http://localhost:8765/");p2.wait_for_selector("#rw-boot");ok("missing script shows banner naming tasks.js","tasks.js" in p2.inner_text("#rw-boot"));c2.close()
    pg.goto("http://localhost:8765/");pg.wait_for_selector("#c")
    pg.click("#c");pg.fill("input[name=name]","Ada Obi");pg.fill("input[name=email]","ada@example.com");pg.fill("input[name=pw]","password123");pg.click("form button")
    pg.wait_for_selector("[data-tab=home]");ok("register and dashboard","Ada" in pg.inner_text("#panel"))
    ok("onboarding shown",  "Start here" in pg.inner_text("#panel"))
    for t in ["tasks","cgpa","studio","cbt","library","exams","opportunities","roadmap","courses","focus","more","profile","home"]:
      go(t);pg.wait_for_timeout(150);ok("tab "+t,len(pg.inner_text("#panel"))>20)
    ok("bottom nav shows 5 buttons on phone",pg.locator(".nav button:visible").count()==5)
    pg.click("[data-tab=more]");ok("More lists 8 modules",pg.locator(".mcard").count()==8)
    pg.click(".mcard[data-go=focus]");pg.click("#fs");pg.wait_for_timeout(1300);ok("focus timer runs",("Pause" in pg.inner_text("#fs")) and pg.inner_text("#fd")!="25:00");pg.click("#fr")
    go("home");ok("dashboard has ring, week chart, quick actions",pg.locator(".ring").count()==1 and pg.locator(".wk").count()==1 and pg.locator(".qa button").count()==6)
    ok("no horizontal overflow at 360px",pg.evaluate("document.documentElement.scrollWidth<=360"))
    go("tasks");pg.fill("#tt","Read MTH 201");pg.select_option("#tp","high");pg.fill("#td","2020-01-01");pg.click("#tf button");pg.wait_for_selector(".task")
    tx=pg.inner_text("#panel");ok("task priority + overdue",("High priority" in tx) and ("Overdue" in tx))
    go("cgpa");pg.fill("#sn","100L First");pg.click("#sf button")
    for code,sc in [("MTH 101","30"),("MTH101","75"),("PHY 101","65")]:
      pg.fill(".cf input[name=code]",code);pg.fill(".cf input[name=score]",sc);pg.click(".cf button")
    ok("cgpa all attempts = 3.00 (F5? 0*3+5*3+4*3 / 9)","3.00" in pg.inner_text("#panel"))
    pg.select_option("#rs","latest");ok("cgpa latest attempt = 4.50","4.50" in pg.inner_text("#panel"))
    go("opportunities");pg.fill("#oq","ptdf");ok("scholarship search",pg.locator("#panel .item h3").count()==1 and "PTDF" in pg.inner_text("#panel"))
    pg.click("[data-so]");ok("scholarship save","★ Saved" in pg.inner_text("#panel"))
    go("profile");pg.click("#chk");pg.wait_for_timeout(1500);ct=pg.inner_text("#chkout");ok("system check: storage + API reachable","can save data" in ct and "Server API reachable" in ct and "❌ Server" not in ct)
    with pg.expect_download() as d:pg.click("#ex")
    path=d.value.path();dat=json.load(open(path));ok("export has v4 + savedOps",dat.get("v")==4 and dat.get("savedOps"))
    with pg.expect_download() as d:pg.click("#csv")
    ok("csv export",b"MTH 101" in open(d.value.path(),"rb").read())
    pg.once("dialog",lambda x:x.accept());pg.set_input_files("#imf",path);pg.wait_for_timeout(400);ok("import round-trip","Backup imported" in pg.inner_text("body"))
    pg.once("dialog",lambda x:x.accept());pg.click("#rs1");pg.wait_for_timeout(300);ok("restore point works","Restored" in pg.inner_text("body"))
    pg.set_input_files("#imf",{"name":"bad.json","mimeType":"application/json","buffer":b'{"profile":{},"cgpa":{"semesters":[{"courses":[{"code":"A","units":99,"grade":"A"}]}]}}'});pg.wait_for_timeout(300);ok("bad import rejected","Invalid backup" in pg.inner_text("#panel"))
    # v3.2 legacy migration
    pg.evaluate("""()=>{const u=JSON.parse(localStorage.rw_users);u['old@x.com']=u['ada@example.com'];localStorage.rw_users=JSON.stringify(u);
      localStorage['rw_data_old@x.com']=JSON.stringify({profile:{full_name:'Old User'},cgpa:{scale:5,semesters:[{id:'a',name:'S1',courses:[{id:'b',code:'ABC1',units:3,score:80,grade:'A',manual:false,retake:false}]}],target:'4'},tasks:{},daily:[],activity:{},shelf:[],audio:[],quizzes:[],chat:[],roadmap:[],custom:[],exams:{list:[]},settings:{remind:false,time:'18:00'}});localStorage.rw_session=JSON.stringify('old@x.com')}""")
    pg.reload();pg.wait_for_selector("[data-tab=home]");go("cgpa");ok("v3.2 data migrated",("5.00" in pg.inner_text("#panel")) and ("ABC1" in pg.inner_text("#panel")))
    # offline
    pg.goto("http://localhost:8765/");pg.wait_for_timeout(1500);ok("service worker active",pg.evaluate("navigator.serviceWorker.getRegistration().then(r=>!!(r&&r.active))"))
    pg.reload();pg.wait_for_timeout(1000);ctx.set_offline(True);pg.reload();pg.wait_for_timeout(1000)
    ok("offline reload serves app",pg.locator("#app").inner_text().strip()!="" )
    b.close()
finally:srv.terminate()
ok("no console/page errors ("+"; ".join(errs[:3])+")",not [e for e in errs if "net::" not in e])
fails=[n for n,c in res if not c];print("\n%d passed, %d failed"%(len(res)-len(fails),len(fails)));sys.exit(1 if fails else 0)
