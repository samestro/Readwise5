const vm=require("vm"),fs=require("fs"),assert=require("assert");
const mk=(scale,resit)=>({TABS:{},esc:String,toast(){},save(){},log(){},uid(){},data:{cgpa:{scale,resit,semesters:[
 {courses:[{code:"MTH 101",units:3,grade:"F"},{code:"PHY101",units:3,grade:"A"}]},{courses:[{code:"MTH101",units:3,grade:"B"}]}]}}});
const run=(scale,resit)=>{const c=mk(scale,resit);vm.createContext(c);vm.runInContext(fs.readFileSync(__dirname+"/../cgpa.js","utf8")+";this.cgpaCalc=cgpaCalc;this.classOf=classOf;this.needed=needed",c);return c};
const near=(a,b)=>assert(Math.abs(a-b)<1e-9,a+" != "+b);
let c=run(5,"all");near(c.cgpaCalc().cgpa,3);
c=run(5,"latest");near(c.cgpaCalc().cgpa,4.5);assert.equal(c.cgpaCalc().units,6);
c=run(4,"latest");near(c.cgpaCalc().cgpa,3.5);
assert.equal(c.classOf(4.5,5),"First Class");assert.equal(c.classOf(3.5,4),"Second Class Upper (2:1)");
assert(/Not reachable/.test(c.needed(4.5,60,5,10,5)));assert(/already secured/.test(c.needed(4.9,60,3,10,5)));
console.log("cgpa tests passed");
