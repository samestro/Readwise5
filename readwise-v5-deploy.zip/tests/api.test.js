process.env.AI_FREE_FALLBACK="off";delete process.env.AI_API_KEY;
const assert=require("assert"),h=require("../api/coach.js");
const call=async(method,headers,body)=>{let out={};const res={setHeader(){},status(c){out.c=c;return this},json(j){out.j=j;return this}};await h({method,headers:{host:"x.app",...headers},body},res);return out};
require("../api/health.js")({}, {setHeader(){},status(){return{json(j){assert(j.ok&&!JSON.stringify(j).includes("KEY"));}}}});
(async()=>{
 assert.equal((await call("GET",{})).c,405);
 assert.equal((await call("POST",{origin:"https://evil.example"},{question:"hi"})).c,403);
 assert.equal((await call("POST",{},{question:""})).c,400);
 for(const m of["constructor","__proto__","toString"])assert.equal((await call("POST",{},{mode:m,question:"hi"})).c,502,m);
 const r=[];for(let i=0;i<14;i++)r.push((await call("POST",{"x-forwarded-for":"9.9.9.9"},{question:"hi"})).c);
 assert.equal(r[13],429);console.log("api tests passed");})();
