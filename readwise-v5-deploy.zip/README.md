# READWISE v5: study PWA for Nigerian students (GitHub + Vercel only)

Static HTML/CSS/vanilla JS plus Vercel serverless routes in `api/`. No build step, no database, no extra services.

## Features
Dashboard (CGPA ring, streak, week chart, exam countdown, real-data recommendations) · CGPA tracker (4.0/5.0, resit rule, target planner, charts, CSV export) · Tasks (priority, due dates, repeat-daily, streaks, reminders) · Focus timer · AI Studio (tutor, planner, quiz, flashcards, narrated explainers, audiobooks, cited research) · CBT practice (timed, scoring, answer review; AI-generated practice questions, never official past papers) · Reading library (Google Books) · Exam countdowns · Scholarships (search, save; marked "Not verified by READWISE") · Course explorer and roadmap · Data saver, dark mode, offline PWA.

## Deploy (checklist)
1. Create a GitHub repository. Upload the **extracted files** from the ZIP (not the ZIP itself) so `index.html` is at the repository root.
2. Vercel > Add New > Project > import the repository. Framework preset **Other**. Root Directory blank. Leave build and output settings empty. Deploy.
3. For reliable AI, add environment variables (Settings > Environment Variables) and redeploy: `AI_API_KEY`, and optionally `AI_BASE_URL` (default `https://api.openai.com/v1`), `AI_MODEL` (default `gpt-4o-mini`). `AI_FREE_FALLBACK=off` disables the unreliable keyless fallback.
4. Open `https://YOUR-SITE.vercel.app/api/health`: you should see `{"ok":true,...}`.
5. Open the app, go to Profile and press **Run system check**.

## If something is not working
A red banner names any file that failed to load (re-upload it and redeploy). A 404 on `/api/health` means the `api/` folder was not uploaded. AI fails more often than not without `AI_API_KEY`.

## Data and accounts (honest limits)
Accounts and data are stored in the browser (localStorage). There is **no server login and no cross-device sync**; clearing browser data erases them. Mitigations: versioned data with automatic migration from v3.x, a daily on-device restore point, validated JSON backup import/export, CSV export, storage-failure warnings. No admin area exists, because a real one needs server-side accounts and a database, which this setup excludes.

## Security
Content-Security-Policy and HSTS in `vercel.json`; all rendered text escaped; imports size-limited, validated and prototype-stripped; CSV export neutralises formulas; AI route validates mode, size and origin and caps tokens; API responses are never cached. The in-memory rate limiter is best effort only (serverless instances do not share memory).

## Testing
`npm test`: CGPA maths, resit rules, API behaviour, data migration/import validation. `python3 tests/smoke.py` (Playwright + Chromium, phone viewport, against a Vercel-like local server with the real headers): 36 checks covering register, onboarding, every tab, bottom navigation, focus timer, tasks, CGPA, scholarships, backup/import/restore, v3.2 migration, system check, startup banner, service worker, offline reload and console errors. All passed when packaged.
Not tested: a physical Android phone, the install prompt, live AI calls, the live Vercel site. Do these manually after deploying.

## Not built
Library bookmarks and reading progress, scholarship application tracking and deadline reminders, CBT question navigation and subject analytics, weekly productivity report, cloud sync and admin tools.
