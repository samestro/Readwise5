"use strict";
const CBT_SUBJECTS=["Mathematics","Physics","Chemistry","Biology","Economics","Government","Literature in English","Christian Religious Studies","Islamic Religious Studies","Geography","Commerce","Accounting","Agricultural Science","Civic Education"];
let cbtSel=[],cbtBusy=false;
TABS.cbt=function(p){
p.innerHTML=`<div class="card"><h2>📝 CBT Practice</h2><p class="muted">Timed, multiple-choice practice in the style of JAMB/UTME and WAEC/NECO computer-based tests. <b>Use of English</b> is compulsory, like the real UTME; pick up to 3 more subjects to match your combo.</p>
<div class="field"><label>Subjects</label><div class="actions"><button type="button" class="secondary small active" disabled>Use of English (compulsory)</button>${CBT_SUBJECTS.map(s=>`<button type="button" class="secondary small ${cbtSel.includes(s)?"active":""}" data-sub="${esc(s)}">${esc(s)}</button>`).join("")}</div></div>
<div class="two"><div class="field"><label>Questions per subject</label><select id="cn"><option value="10">10 (quick practice)</option><option value="20" selected>20</option><option value="40">40 (full JAMB-length)</option></select></div><div class="field"><label>Time per question</label><select id="ct"><option value="45">45 sec</option><option value="60" selected>60 sec</option><option value="90">90 sec</option></select></div></div>
<button id="start">Start CBT practice</button><p id="sf" class="error" role="alert"></p></div><div id="cb"></div>
<div class="card"><h3>Recent CBT scores</h3>${data.quizzes.filter(x=>x.cbt).slice(-8).reverse().map(x=>`<div class="item">${esc(x.topic)} — <b>${x.score}/${x.total}</b> <span class="muted smalltext">${esc(x.date)}</span></div>`).join("")||'<p class="muted smalltext">No CBT practice yet. Your results are saved here after each session.</p>'}</div>
<div class="notice">This mimics the real exam format for practice only — question style, difficulty and scoring are AI-generated estimates, not an official JAMB/WAEC paper. Always also use past questions and your official syllabus.</div>`;
$$("[data-sub]").forEach(b=>b.onclick=()=>{const s=b.dataset.sub;if(cbtSel.includes(s))cbtSel=cbtSel.filter(x=>x!==s);else{if(cbtSel.length>=3){toast("Max 3 extra subjects — like the real JAMB combo (4 with English).");return}cbtSel.push(s)}TABS.cbt(p)});
$("#start").onclick=async()=>{
  if(cbtBusy)return;
  const n=+$("#cn").value,t=+$("#ct").value,btn=$("#start");
  if(!cbtSel.length){$("#sf").textContent="Pick at least one more subject besides Use of English.";return}
  const subs=["Use of English",...cbtSel];
  $("#sf").textContent="";cbtBusy=true;busy(btn,true,"Preparing questions… (up to a minute)");
  try{
    const bank={};
    for(const sub of subs){
      const a=await callAI("cbt",sub,`Generate ${n} JAMB/UTME and WAEC-standard multiple choice questions for the subject: ${sub}. Cover a realistic spread of topics across the Nigerian senior-secondary syllabus for this subject.`);
      const items=validQ(parseJSON(a));
      if(!items.length){$("#sf").textContent=`Could not prepare ${sub} questions right now — AI may be unavailable. Try again shortly, or pick fewer subjects.`;busy(btn,false,"Start CBT practice");cbtBusy=false;return}
      bank[sub]=items.slice(0,n)
    }
    log("ai");runCBT($("#cb"),bank,t)
  }catch(e){fail(e)}finally{busy(btn,false,"Start CBT practice");cbtBusy=false}
}};
function runCBT(box,bank,secPerQ){
const subs=Object.keys(bank);let si=0,qi=0,score=0,total=0,subScore=0,subTotal=0,timer=null,left=secPerQ;
const allRes=[],det=[];
const finish=()=>{clearInterval(timer);const pct=total?Math.round(score/total*100):0;
box.innerHTML=`<div class="card"><h2>CBT Practice complete</h2><p class="big">${score}/${total}</p><p class="muted">${pct}% overall</p><div class="list">${allRes.map(r=>`<div class="item">${esc(r.sub)}: <b>${r.score}/${r.n}</b></div>`).join("")}</div><p class="muted smalltext">Rough estimate only: ~${Math.round((total?score/total:0)*400)}/400 on a JAMB-style scale. Real exam scoring, negative marking (if any) and question pools differ — use this purely for practice.</p><h3>Review your answers</h3><div class="list">${det.map((d,i)=>`<div class="item"><b>${esc(d.sub)} · Q${i+1}</b> ${d.k===d.q.answer?"✅":"❌"}<p>${esc(d.q.q)}</p><p class="smalltext">Your answer: ${d.k<0?"none (time up)":esc(d.q.options[d.k])} · Correct: <b>${esc(d.q.options[d.q.answer])}</b></p>${d.q.explain?`<p class="muted smalltext">${esc(d.q.explain)}</p>`:""}</div>`).join("")}</div><p class="muted smalltext">AI-generated practice questions, not official past questions. Explanations can contain errors.</p><button id="done">Done</button></div>`;
if(pct>=70)confetti();log("quizzes");$("#done").onclick=()=>TABS.cbt($("#panel"))};
const showQ=()=>{clearInterval(timer);left=secPerQ;const sub=subs[si],items=bank[sub],q=items[qi],L="ABCD";
box.innerHTML=`<div class="card"><div class="actions" style="justify-content:space-between"><b>${esc(sub)} — Q${qi+1}/${items.length}</b><span id="tmr" class="chip">⏱ ${left}s</span></div><div class="bar" style="margin:8px 0"><i style="width:${(qi)/items.length*100}%"></i></div><p>${esc(q.q)}</p><div class="list">${q.options.map((o,k)=>`<button class="secondary opt" data-k="${k}" style="text-align:left">${L[k]}. ${esc(o)}</button>`).join("")}</div></div>`;
timer=setInterval(()=>{left--;const e=$("#tmr");if(e)e.textContent="⏱ "+left+"s";if(left<=0)mark(-1)},1000);
$$(".opt").forEach(o=>o.onclick=()=>mark(+o.dataset.k))};
const mark=(k)=>{clearInterval(timer);const sub=subs[si],items=bank[sub],q=items[qi];det.push({sub,q,k});total++;subTotal++;if(k===q.answer){score++;subScore++}
qi++;if(qi>=items.length){allRes.push({sub,score:subScore,n:subTotal});data.quizzes.push({date:today(),topic:"CBT: "+sub,score:subScore,total:subTotal,cbt:true});data.quizzes=data.quizzes.slice(-40);subScore=0;subTotal=0;save();si++;qi=0}
if(si>=subs.length)finish();else showQ()};
showQ()}
